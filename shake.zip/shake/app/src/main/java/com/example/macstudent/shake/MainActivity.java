package com.example.macstudent.shake;

import android.content.Context;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;

import com.squareup.seismic.ShakeDetector;

public class MainActivity extends AppCompatActivity implements ShakeDetector.Listener {

    //global var if light is off or on
    boolean lightOn = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //1. create a bunch of nonsense variables
        //that are used to detect when the phone is shaking
        //setup your phone to deal with shakes
        SensorManager manager = (SensorManager) getSystemService(SENSOR_SERVICE);
        ShakeDetector detector = new ShakeDetector(this);
        detector.start(manager);
    }


    //this is mandatory function
    //it's required by the shakedetector.listener class
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void hearShake() {
       //2. this function automatically gets called
       //every time you shake the phone

       //print out a message when phone shakes
       Log.d("Navu","phone is shaking");
        Toast.makeText(this,"shaking",Toast.LENGTH_SHORT).show();

        //turn on flashlight when phone shakes!
        CameraManager cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);

        //turn on the flash on your phone!
        //1. which camera do you want(front or back)
        try {
            String cameraID = cameraManager.getCameraIdList()[0];//back camera

            if (lightOn == false) {
                //2. turn the flash on
                cameraManager.setTorchMode(cameraID, true);
                Log.d("Navu", "Turning flash on");
                Toast.makeText(this, "flash on", Toast.LENGTH_SHORT).show();
                lightOn = true;
                //turn off
                //cameraManager.setTorchMode(cameraID,false);
            } else {
                cameraManager.setTorchMode(cameraID,false);
                Log.d("Navu", "Turning flash off");
                Toast.makeText(this, "flash off", Toast.LENGTH_SHORT).show();
                lightOn = false;
            }
        }
        catch(Exception e){
            Log.d("Navu","Error turning on camera flash");
            Toast.makeText(this,"flash not working",Toast.LENGTH_SHORT).show();
        }



    }



}
