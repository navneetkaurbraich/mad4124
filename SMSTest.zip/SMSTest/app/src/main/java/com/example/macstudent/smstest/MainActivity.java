package com.example.macstudent.smstest;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.IOException;
import java.util.Iterator;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {


    //okhttp variable
    OkHttpClient client = new OkHttpClient();


    //user interface variable(outlets)
    TextView textviewMain;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //initiatialize the variable
        textviewMain = (TextView)findViewById(R.id.textviewMain);

    }

    //action(click handler) for my button
    public void buttonPressed(View v){

        //option 1 for output
        System.out.println("Person clicked the button");

        //option 2 for output
        Log.d("Navu","clicked");

        //1. tell system what url you want to go to
        Request request = new Request.Builder().url("https://api.coindesk.com/v1/bpi/historical/close.json?currency=BRL&start=2018-01-01&end=2018-01-10" +
                "").build();

        //2. send the request to internet and wait for response
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                //what happen if request fails?

                Log.d("Navu","An error occured");
                e.printStackTrace(); //print the error
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {


                Log.d("Navu","Request Successful...");

                if(response.isSuccessful()){
                    //what happen if request was successful?
                    final String reply = response.body().string();


                        try{
                            //1. MAKE A JSON OBJECT
                            JSONObject json = new JSONObject(reply);


                            //2. parse the stuff inside the object
                            //int userId = json.getInt("userId");
                            //String title = json.getString("title");
                            //Boolean done = json.getBoolean("completed");
                            JSONObject bpi = json.getJSONObject("bpi");
                            String disclaimer = json.getString("disclaimer");

                            //3. do something with these var
                           // Log.d("Navu",Integer.toString(userId));
                            //Log.d("Navu", title);
                            //Log.d("Navu", Boolean.toString(done));
                            Log.d("Navu", disclaimer);
                            Log.d("Navu", bpi.toString());

                            //4. lets do some stupid logic
                            Iterator<String> iterator = bpi.keys();

                            while (iterator.hasNext()) {
                                String key = iterator.next();

                                double price = bpi.getDouble(key);

                                Log.d("Navu", "Key:");
                                Log.d("Navu", key);

                                Log.d("Navu", "Printing out the item:");
                                Log.d("Navu", Double.toString(price));

                            }




                          /*
                            if(done ==false){
                                Log.d("Navu", "The system is down..");
                            }
                            if(userId == 1){
                                Log.d("Navu", title);
                            }*/
                        }
                        catch(Exception e){
                            Log.d("Navu","An error occured parsing JSON");
                    }



                    //output the json response to terminal
                    Log.d("Navu",reply);

                    //if uh wanna ouput to ui
                    MainActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            //do your user interface nonsense here
                            textviewMain.setText(reply);

                        }
                    });
                }


            }
        });

    }
}
